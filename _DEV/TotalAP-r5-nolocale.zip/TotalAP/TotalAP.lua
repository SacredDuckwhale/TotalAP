local itemEffects; -- loaded on init from separate (script-generated) file: ItemEffects\ItemEffects.lua via global TotalAP

local L = LibStub("AceLocale-3.0"):GetLocale("TotalAP") -- Default locale = enGB (also US), most others are still TODO

-- Shorthands
local aUI = C_ArtifactUI
local slashCommand = "/ap";

-- Addon metadata (used in messages, mainly)
local addonName = ...;
local addonVersion = GetAddOnMetadata(addonName, "Version");
--local addonInterfaceVersion = GetAddOnMetadata(addonName, "Interface"); DOESNT WORK

-- Internal vars
local tempItemLink, tempItemID, currentItemLink, currentItemID, currentItemTexture; -- used for bag scanning and tooltip display
local numItems, inBagsTotalAP, numTraitsAvailable, artifactProgressPercent = 0, 0, 0, 0; -- used for tooltip text
local TotalAPFrame, TotalAPButton; -- UI elements/frames
local settings; -- savedVars

-- Print debug messages (if enabled))(duh)
local function Debug(msg)
	if settings.debugMode then
		print(format("|c000072CA" .. "%s-Debug: " .. "|c00E6CC80%s", addonName, msg)); 
	end
end
		
-- Print regular addon messages (if enabled)
local function ChatMsg(msg)
	if settings.verbose then
		print(format("|c00CC5500" .. "%s: " .. "|c00E6CC80%s", addonName, msg)); -- TODO: Use addonName?
	end
end

 -- Format number as short (15365 = 15.3k etc.) -> All credit goes to Google and whoever wrote it on wowinterface (I think?). I did NOT reinvent the wheel
 local function Short(value,format) 
	if type(value) == "number" then
		local fmt
		if value >= 1000000000 or value <= -1000000000 then
			fmt = "%.1fb"
			value = value / 1000000000
		elseif value >= 10000000 or value <= -10000000 then
			fmt = "%.1fm"
			value = value / 1000000
		elseif value >= 1000000 or value <= -1000000 then
			fmt = "%.2fm"
			value = value / 1000000
		elseif value >= 100000 or value <= -100000 then
			fmt = "%.0fk"
			value = value / 1000
		elseif value >= 10000 or value <= -10000 then
			fmt = "%.1fk"
			value = value / 1000
		else
			fmt = "%d"
			value = math.floor(value + 0.5)
		end
		if format then
			return fmt:format(value)
		end
		return fmt, value
	else
		local fmt_a, fmt_b
		local a, b = value:match("^(%d+)/(%d+)$")
		if a then
			a, b = tonumber(a), tonumber(b)
			if a >= 1000000000 or a <= -1000000000 then
				fmt_a = "%.1fb"
				a = a / 1000000000
			elseif a >= 10000000 or a <= -10000000 then
				fmt_a = "%.1fm"
				a = a / 1000000
			elseif a >= 1000000 or a <= -1000000 then
				fmt_a = "%.2fm"
				a = a / 1000000
			elseif a >= 100000 or a <= -100000 then
				fmt_a = "%.0fk"
				a = a / 1000
			elseif a >= 10000 or a <= -10000 then
				fmt_a = "%.1fk"
				a = a / 1000
			end
			if b >= 1000000000 or b <= -1000000000 then
				fmt_b = "%.1fb"
				b = b / 1000000000
			elseif b >= 10000000 or b <= -10000000 then
				fmt_b = "%.1fm"
				b = b / 1000000
			elseif b >= 1000000 or b <= -1000000 then
				fmt_b = "%.2fm"
				b = b / 1000000
			elseif b >= 100000 or b <= -100000 then
				fmt_b = "%.0fk"
				b = b / 1000
			elseif b >= 10000 or b <= -10000 then
				fmt_b = "%.1fk"
				b = b / 1000
			end
			local fmt = ("%s/%s"):format(fmt_a, fmt_b)
			if format then
				return fmt:format(a, b)
			end
			return fmt, a, b
		else
			return value
		end
	end
end

-- Calculate the total number of purchaseable traits (using AP from both the equipped artifact and from AP tokens in the player's inventory)
local function GetNumAvailableTraits()
	
	if not aUI or not HasArtifactEquipped() then
		Debug("Called GetNumAvailableTraits, but the artifact UI is unavailable... Is an artifact equipped?");
		return 0;
	end
		
	local thisLevelUnspentAP, numTraitsPurchased = select(5, aUI.GetEquippedArtifactInfo());	
	local numTraitsAvailable = MainMenuBar_GetNumArtifactTraitsPurchasableFromXP(numTraitsPurchased, thisLevelUnspentAP + inBagsTotalAP); -- This is how many times the weapon can be leveled up with AP from bags AND already used (but not spent) AP from this level
	Debug(format("Called GetNumAvailableTraits -> %s new traits available!", numTraitsAvailable or 0));
	
	return numTraitsAvailable or 0;
end

-- Calculate progress towards next artifact trait (for the equipped artifact)
local function GetArtifactProgressPercent()
		
		if not aUI or not HasArtifactEquipped() then
			Debug("Called GetArtifactProgressPercent, but the artifact UI is unavailable (is an artifact equipped?)...");
			return 0;
		end
	
		local thisLevelUnspentAP, numTraitsPurchased = select(5, aUI.GetEquippedArtifactInfo());	
		local nextLevelRequiredAP = aUI.GetCostForPointAtRank(numTraitsPurchased); 
		
		local percentageOfCurrentLevelUp = (thisLevelUnspentAP + inBagsTotalAP) / nextLevelRequiredAP*100;
		Debug(format("Called GetArtifactProgressPercent -> Progress is: %s%% towards next trait!", percentageOfCurrentLevelUp or 0)); -- TODO: > 100% becomes inaccurate due to only using cost for THIS level, not next etc?
		
		return percentageOfCurrentLevelUp or 0;
end

-- Extract an item's name from its item link
local function GetItemNameFromLink(itemLink)
	local _, _, Color, Ltype, Id, Enchant, Gem1, Gem2, Gem3, Gem4, Suffix, Unique, LinkLvl, reforging, itemName = string.find(itemLink, "|?c?f?f?(%x*)|?H?([^:]*):?(%d+):?(%d*):?(%d*):?(%d*):?(%d*):?(%d*):?(%-?%d*):?(%-?%d*):?(%d*):?(%d*)|?h?%[?([^%[%]]*)%]?|?h?|?r?")
	return itemName or "";
end

-- Load default settings (will overwrite SavedVars)
local function RestoreDefaultSettings()

	TotalArtifactPowerSettings = 	{	
															debugMode = false;
															verbose = true;
															showNumItems = true;
															showProgressReport = true;
															showActionButton = true;
															showButtonGlowEffect = true;
															showLoginMessage = true;
														--	actionButtonSize = 40;
															specIconSize = 20;
														};
	settings = TotalArtifactPowerSettings;
end

-- Verify saved variables and reset them in case something was corrupted/tampered with/accidentally screwed up while updating
local function VerifySettings()
	
	settings = TotalArtifactPowerSettings;
		
	if not settings then -- Can't verify what isn't there... although this shouldn't really happen
		Debug("Can't verify settings because they don't exist...");
		return false;
	end
	
	if not type(settings.debugMode) == "boolean" then
		settings.debugMode = true;
	end
	
	if not type(settings.verbose) == "boolean" then
		settings.verbose = true;
	end
	
	if not type(settings.showNumItems) == "boolean" then
		settings.showNumItems = true;
	end
	
	if not type(settings.showProgressReport) == "boolean" then
		settings.showProgressReport = true;
	end
	
	if not type(settings.showActionButton) == "boolean" then
		settings.showActionButton = true;
	end
	
	if not type(settings.showButtonGlowEffect) == "boolean" then
		settings.showButtonGlowEffect = true;
	end
	
	if not type(settings.showLoginMessage) == "boolean" then
		settings.showLoginMessage = true;
	end
	
	-- if not type(settings.actionButtonSize) == "number" and settings.actionButtonSize > 0 then
		-- settings.actionButtonSize = 40;
	-- end
	
	if not type(settings.specIconSize) == "number" and settings.specIconSize > 0 then
		settings.specIconSize = 20;
	end

	Debug("Settings have been verified and set to their default values if any were invalid...");
	return true;
	
end

-- Load saved vars and itemEffects DB, attempt to verify SavedVars (simple type-check, nothing fancy)
local function LoadSettings()
	
	-- Load item spell ffects from global (shared) var
	itemEffects = TotalAP.itemEffects;
	
	if not TotalArtifactPowerSettings then 	-- Load default settings
		RestoreDefaultSettings(); 
	else -- check for types and proper values (TODO)
		if not VerifySettings then
			ChatMsg("Settings couldn't be verified... There might be a problem with the SavedVars.");
		end
	end
	
	settings = TotalArtifactPowerSettings;
	
end

-- Check for artifact power tokens in the player's bags 
 local function CheckBags()
 
	local bag, slot;
	numItems, inBagsTotalAP = 0, 0; -- Each scan has to reset the (global) counter used by the tooltip and update handlers
	
	-- Check all the items in bag against AP token LUT (via their respective spell effect = itemEffectsDB)to find matches
	for bag = 0, NUM_BAG_SLOTS do
		for slot = 1, GetContainerNumSlots(bag) do
			tempItemLink = GetContainerItemLink(bag, slot);

			if tempItemLink and tempItemLink:match("item:%d")  then
					tempItemID = GetItemInfoInstant(tempItemLink);
					local spellID = itemEffects[tempItemID];
					
				if spellID then	-- Found AP token :D	
					numItems = numItems + 1
					
					-- Extract AP amount (after AK) from the description
					local spellDescription = GetSpellDescription(spellID); -- Always contains the AP number, as only AP tokens are in the LUT
					local m = spellDescription:match("%s?(%d+%,?%.?%s?%d*)%s?");  -- Match pattern: <optional space><number | number separated by comma, point, or space> <optional space> (Should work for all locales due to BreakUpLargeNumbers being used in the UI)		
					m = string.gsub(string.gsub(m, "%,", ""), "%.", ""); -- Remove commas and points (to convert the value to an actual number)

				inBagsTotalAP = inBagsTotalAP + tonumber(m);
				
				-- Store current AP item in globals (to display in button, use via keybind, etc.)
				currentItemLink = tempItemLink;
				currentItemID = tempItemID;
				currentItemTexture = GetItemIcon(currentItemID);
				
				Debug(format("Set currentItemTexture to %s", currentItemTexture));
				
				Debug(format("Found AP item: %s (%d) with texture %d",	currentItemLink, currentItemID, currentItemTexture)); 
				end
			end
		end
	end
end

-- Toggle spell overlay (glow effect) on an action button
local function FlashActionButton(actionButton, showGlowEffect)
	
	if showGlowEffect == nil then showGlowEffect = true; end -- Default = enable glow if no arg was passed
	
	if not actionButton then
		Debug("Called FlashActionButton, but actionButton is nil. Abort, abort!");
		return false
	else
		if showGlowEffect then
			ActionButton_ShowOverlayGlow(actionButton);
		else
			ActionButton_HideOverlayGlow(actionButton);
		end
	end
end	

-- Registers button with Masque
local function MasqueRegister()
	local Masque = LibStub("Masque", true);
		 if Masque then
			 local group = Masque:Group("TotalAP - Artifact Power Tracker");
			 group:AddButton(TotalAPButton);
			 Debug("Added button to Masque groups! Its appearance should now be controlled by Masque..."); -- TODO: Size/Texture also via masque? Will it overwrite my settings?
		 end
end

-- Updates the style (by re-skinning) if using Masque, and keep button proportions so that it remains square
local function MasqueUpdate()

	 local Masque = LibStub("Masque", true);
	 
	 if Masque then
		 
		 local group = Masque:Group("TotalAP - Artifact Power Tracker");
		 group:ReSkin();
		 
		 Debug("Updated Masque skinning");
		 
	end
	
	local w, h = TotalAPButton:GetWidth(), TotalAPButton:GetHeight();
	if w > h then TotalAPButton:SetWidth(h) else TotalAPButton:SetHeight(w); end;
	-- settings.actionButtonSize = min(w, h);
	Debug("Updated button size to keep it proportionate (square)");
	 
end

-- Updates the action button whenever necessary to re-scan for AP items
local function UpdateActionButton()

	-- Also only show button if AP items were found, an artifact weapon is equipped in the first place, settings allow it, addons aren't locked from the player being in combat, and the artifact UI is available
	if numItems > 0 and TotalAPButton and not InCombatLockdown() and settings.showActionButton and currentItemID and aUI and HasArtifactEquipped() then  
		
		currentItemTexture = GetItemIcon(currentItemID) or "";
		TotalAPButton.icon:SetTexture(currentItemTexture);
		Debug(format("Set currentItemTexture to %s", currentItemTexture));
	
		local itemName = GetItemInfo(currentItemLink) or "";
		if itemName == "" then -- item isn't cached yet -> skip update until the next BAG_UPDATE_DELAYED (should only happen after a fresh login)
			Debug("itemName not cached yet. Skipping this update...");
			return false;
		end
		
		Debug(format("Current item bound to action button: %s = % s", itemName, currentItemLink));
		
		TotalAPButton:SetAttribute("type", "item");
		TotalAPButton:SetAttribute("item", itemName);
		
		Debug(format("Update changed item bound to action button: %s = % s", itemName, currentItemLink));
		
		TotalAPButton:Show();
		MasqueUpdate();
		
		-- Transfer cooldown animation to the button (would otherwise remain static, which feels artificial)
		local start, duration, enabled = GetItemCooldown(currentItemID)
		if duration > 0 then
				TotalAPButton.cooldown:SetCooldown(start, duration)
		end
	
		if TotalAPButton:IsMouseOver() then -- Display tooltip when mouse hovers over the action button
			GameTooltip:SetHyperlink(currentItemLink);
		end
		
		-- Update available traits and trigger spell overlay effect if necessary
		numTraitsAvailable = GetNumAvailableTraits(); 
		if settings.showButtonGlowEffect and numTraitsAvailable > 0 then
			FlashActionButton(TotalAPButton, true);
			Debug("Activating button glow effect while processing UpdateActionButton...");
		else
			FlashActionButton(TotalAPButton, false);
			Debug("Deactivating button glow effect while processing UpdateActionButton...");
		end
	else
		TotalAPButton:Hide();
		Debug("Not all criteria are met. Hiding action button...");
	end
end	

-- Initialise action button
local function CreateActionButton()
	
	if not TotalAPButton then -- if button already exists, this was called before -> Skip initialisation
		
		TotalAPButton = CreateFrame("Button", "TotalAPButton", UIParent, "ActionButtonTemplate, SecureActionButtonTemplate");
		TotalAPButton:SetFrameStrata("MEDIUM");
		TotalAPButton:SetClampedToScreen(true);
		
		-- TotalAPButton:SetSize(settings.actionButtonSize, settings.actionButtonSize); 
		TotalAPButton:SetPoint("CENTER");

		TotalAPButton:SetMovable(true);
		TotalAPButton:EnableMouse(true)
		TotalAPButton:RegisterForClicks("LeftButtonUp", "RightButtonUp");
		TotalAPButton:RegisterForDrag("LeftButton"); -- left button = resize or reposition

		TotalAPButton:SetResizable(true);
		TotalAPButton:SetMinResize(20, 20); -- Let's not go there and make it TINY, shall we?
		TotalAPButton:SetMaxResize(200, 200); -- ... but no one likes a stretched, giant button either)
		
		currentItemTexture = GetItemIcon(currentItemID) or "";
		TotalAPButton.icon:SetTexture(currentItemTexture);
		Debug(format("Set currentItemTexture to %s", currentItemTexture));
		
		Debug(format("Created button with currentItemTexture = %s (currentItemID = %d)", currentItemTexture, currentItemID));
		

		-- Action handlers
		TotalAPButton:SetScript("OnEnter", function(self)  -- (to show the tooltip on mouseover)
		
			if currentItemID then
			
				GameTooltip:SetOwner(TotalAPButton, "ANCHOR_RIGHT");
				GameTooltip:SetHyperlink(currentItemLink);
				Debug(format("OnEnter -> mouse entered TotalAPButton... Displaying tooltip for currentItemID = %s.", currentItemID));
				
				local itemName = GetItemInfo(currentItemLink) or "<none>";
				Debug(format("Current item bound to action button: %s = % s", itemName, currentItemLink));
				Debug(format("Attributes: type = %s, item = %s", self:GetAttribute("type") or "<none>", self:GetAttribute("item") or "<none>"));
			
			else  Debug("OnEnter  -> mouse entered TotalAPButton... but currentItemID is nil so a tooltip can't be displayed!"); end
			
			Debug(format("Button size is width = %d, height = %d, settings.actionButtonSize = %d", self:GetWidth(), self:GetHeight(), settings.actionButtonSize or 0));
			
		end);
		
		TotalAPButton:SetScript("OnLeave", function(self)  -- (to hide the tooltip afterwards)
			GameTooltip:Hide();
		end);
			
		TotalAPButton:SetScript("OnHide", function(self) -- (to hide the tooltip when leaving the button)
			Debug("Button is being hidden. Disabled click functionality...");
			self:SetAttribute("type", nil);
			self:SetAttribute("item", nil);
		end);
	
		TotalAPButton:SetScript("OnDragStart", function(self) -- (to allow dragging the button, and also to resize it)
		
		if self:IsMovable() and IsAltKeyDown() then self:StartMoving(); -- Alt -> Move button
		elseif self:IsResizable() and IsShiftKeyDown() then self:StartSizing(); end -- Shift -> Resize button
			
		self.isMoving = true;
	
		end);
		
		TotalAPButton:SetScript("OnUpdate", function(self) -- (to update the button skin and proportions while being resized)
			
			if self.isMoving then
				Debug(format("Button is moving, width = %d, height = %d, settings.actionButtonSize = %d", self:GetWidth(), self:GetHeight(), settings.actionButtonSize or 0));

				MasqueUpdate();
			end
		end)
		
		TotalAPButton:SetScript("OnDragStop", function(self) -- (to update the button skin and stop it from being moved after dragging has ended)
			
			Debug("Button was dragged but now received OnDragStop");
			self:StopMovingOrSizing();
			
			MasqueUpdate();
			self.isMoving = false;
			FlashActionButton(TotalAPButton, false); -- Re-enable immediately, this is in case the button changed sizes since the spell overlay was first enabled; 
			FlashActionButton(TotalAPButton, settings.showGlowEffect); -- primarily to reapply the glow effect with the button's proper size (otherwise it looks off). Can't do this in UpdateActionButton or it will flash during inventory changes etc.
		end)
	
		TotalAPButton:SetScript("OnEvent", function(self, event, ...) --  (to update and show/hide the button when entering or leaving combat/pet battles)

			if event == "BAG_UPDATE_DELAYED" then  -- inventory has changed -> recheck bags for AP items and update button display

				Debug("Scanning bags and updating action button after BAG_UPDATE_DELAYED...");
				CheckBags();
				UpdateActionButton();
				
			elseif event == "PLAYER_REGEN_DISABLED" or event == "PET_BATTLE_OPENING_START" or (event == "UNIT_ENTERED_VEHICLE" and ... == "player") then -- Hide button while AP items can't be used
				
				Debug("Player entered combat, vehicle, or pet battle... Hiding button!");
				self:Hide();
				self:UnregisterEvent("BAG_UPDATE_DELAYED");
				
			elseif event == "PLAYER_REGEN_ENABLED" or event == "PET_BATTLE_CLOSE" or (event == "UNIT_EXITED_VEHICLE" and ... == "player") then -- Show button once they are usable again
			
				--if numItems > 0 and not InCombatLockdown() and settings.showActionButton then 
					--self:Show(); 
					--Debug("Player left combat , vehicle, or pet battle... Showing button!");
				-- end
				Debug("Player left combat , vehicle, or pet battle... Updating action button!");
				UpdateActionButton();
				
				self:RegisterEvent("BAG_UPDATE_DELAYED");
					
			elseif event == "ARTIFACT_XP_UPDATE" or event == "ARTIFACT_UPDATE" then -- Recalculate tooltip display and update button when AP items are used or new traits purchased
				
				Debug("Updating action button after ARTIFACT_UPDATE or ARTIFACT_XP_UPDATE...");
				UpdateActionButton();
	
		end
	end);

		-- Register action button with Masque to allow it being skinned
		MasqueRegister();
	end	
end

	-- Register all relevant events required to update the button
local function RegisterUpdateEvents()

		TotalAPButton:RegisterEvent("BAG_UPDATE_DELAYED"); -- Possible inventory change -> Re-scan bags
		TotalAPButton:RegisterEvent("PLAYER_REGEN_DISABLED"); -- Player entered combat -> Hide button
		TotalAPButton:RegisterEvent("PLAYER_REGEN_ENABLED"); -- Player left combat -> Show button
		TotalAPButton:RegisterEvent("PET_BATTLE_OPENING_START"); -- Player entered pet battle -> Hide button
		TotalAPButton:RegisterEvent("PET_BATTLE_CLOSE"); -- Player left pet battle -> Show button
		TotalAPButton:RegisterEvent("UNIT_ENTERED_VEHICLE");
		TotalAPButton:RegisterEvent("UNIT_EXITED_VEHICLE");
		TotalAPButton:RegisterEvent("ARTIFACT_XP_UPDATE"); -- gained AP
		TotalAPButton:RegisterEvent("ARTIFACT_UPDATE"); -- new trait learned?

end

-- Toggle action button via keybind (doesn't change the settings, and won't work if no AP items are available)
function TotalAP:ToggleActionButton()
	settings.showActionButton = not settings.showActionButton;
	UpdateActionButton();
end

-- Slash command handling
local function SlashCommandHandler(msg)

	-- Preprocessing of user input
	msg = string.lower(msg);
	local command, param = msg:match("^(%S*)%s*(.-)$");
	
	if command == "counter" then -- Toggle counter display in tooltip
	
		if not settings.showNumItems then ChatMsg(L["TotalAP: Item counter enabled."]);
		else ChatMsg(L["Item counter disabled."]);
		end
		
		settings.showNumItems = not settings.showNumItems;
	
	elseif command == "progress" then -- Enable progress report in tooltip
	
		if not settings.showProgressReport then ChatMsg(L["TotalAP: Progress report enabled."]);
		else ChatMsg(L["Progress report disabled."]);
		end
		
		settings.showProgressReport = not settings.showProgressReport;
	
	elseif command == "glow" then -- Toggle button spell overlay effect -> Notification that new traits are available
		
		if not settings.showButtonGlowEffect then
			settings.showButtonGlowEffect = true; 
			ChatMsg(L["Button glow effect enabled."]);
		else
			settings.showButtonGlowEffect = false;
			ChatMsg(L["Button glow effect disabled."]);
		end
		
		UpdateActionButton();
		
	elseif command == "button" then -- Toggle button visibility (tooltip functionality remains)

		if settings.showActionButton then
			ChatMsg(L["Action button is now hidden."]);
		else
			ChatMsg(L["Action button is now.shown."]);
		end
		
		settings.showActionButton = not settings.showActionButton;
		UpdateActionButton();
		
	elseif command == "loginmsg" then -- Toggle notification when loading/logging in
		
		if settings.showLoginMessage then
			ChatMsg(L["Login message is now hidden."]);
		else
			ChatMsg(L["Login message is now shown."]);
		end
		
	settings.showLoginMessage = not settings.showLoginMessage;
		
	elseif command == "reset" then -- Load default values for all settings
		
		RestoreDefaultSettings();
		ChatMsg(L["Default settings loaded."]);
		
		UpdateActionButton();
	
	elseif command == "debug" then -- Toggle debug mode
	
		if settings.debugMode then
			ChatMsg(L["Debug mode disabled."]);
		else
			ChatMsg(L["Debug mode enabled."]);
		end
		
		settings.debugMode = not settings.debugMode;
		
	else -- Display help / list of commands
		
		ChatMsg(L["[List of available commands]"]);
		ChatMsg(slashCommand .. " counter - " .. L["Toggle display of the item counter"]);
		ChatMsg(slashCommand .. " progress - " .. L["Toggle display of the progress report"]);
		ChatMsg(slashCommand .. " glow - " .. L["Toggle spell overlay notification (glow effect) when new traits are available"]);
		ChatMsg(slashCommand .. " button - " .. L["Toggle button visibility (tooltip visibility is unaffected)"]);
		ChatMsg(slashCommand .. " loginmsg - " .. L["Toggle login message on load"]);
		ChatMsg(slashCommand .. " reset - " .. L["Load default settings (will overwrite any changes made)"]);
		ChatMsg(slashCommand .. " debug - " .. L["Toggle debug mode (not particularly useful as long as everything is working as expected)"]);
	
	end
end

-- Display tooltip when hovering over an AP item
GameTooltip:HookScript('OnTooltipSetItem', function(self)
	
	local _, tempItemLink = self:GetItem();
	if type(tempItemLink) == "string" then

		tempItemID = GetItemInfoInstant(tempItemLink);
		
		if itemEffects[tempItemID] then -- Only display tooltip addition for AP tokens
			
			local artifactID, _, artifactName = C_ArtifactUI.GetEquippedArtifactInfo();
			
			if artifactID and artifactName then	

				-- Display spec and artifact info
				local spec = GetSpecialization();
				if spec then
					local _, specName, _, specIcon, _, specRole = GetSpecializationInfo(spec);
					local classDisplayName, classTag, classID = UnitClass("player");
					
					if specIcon then
						self:AddLine(format('\n|T%s:%d|t [%s]', specIcon,  settings.specIconSize or 16, artifactName), 230/255, 204/255, 128/255); -- TODO: Colour green/red or something if it's the offspec? Can use classTag or ID for this
					end
				end
			
				-- Display AP summary
				if numItems > 1 and settings.showNumItems then 
					self:AddLine(format(L["\n%s Artifact Power in bags (%d items)"], Short(inBagsTotalAP, true), numItems), 230/255, 204/255, 128/255);
				else
					self:AddLine(format(L["\n%s Artifact Power in bags"], Short(inBagsTotalAP, true)) , 230/255, 204/255, 128/255);
				end
			
				-- Calculate progress towards next trait
				if HasArtifactEquipped() and settings.showProgressReport	then
						
						-- Recalculate progress percentage and number of available traits when showing tooltip
						numTraitsAvailable = GetNumAvailableTraits(); 
						artifactProgressPercent = GetArtifactProgressPercent(); -- TODO: Why doesn't this update after purchasing a trait? I can update it manually in UpdateActionButton but it shouldn't show "0%"...
							
						-- Display progress
						if numTraitsAvailable > 1 then -- several new traits are available
							self:AddLine(format(L["%d new traits available - Use AP now to level up!"], numTraitsAvailable), 0/255, 255/255, 0/255);
						elseif numTraitsAvailable > 0 then -- exactly one new is trait available
							self:AddLine(format(L["New trait available - Use AP now to level up!"]), 0/255, 255/255, 0/255);
						else -- No traits available - too bad :(
							self:AddLine(format(L["Progress towards next trait: %d%%"], artifactProgressPercent));
						end
				end
			end
			
		self:Show();
		
		end
	end
end);

 -- One-time execution on load -> Piece everything together
 do
	LoadSettings();  -- from saved vars
	
	local f = CreateFrame("Frame", "InvisibleTotalAPFrame");

	f:RegisterEvent("ADDON_LOADED");
	f:RegisterEvent("PLAYER_LOGIN");
	f:RegisterEvent("PLAYER_ENTERING_WORLD");
	
	f:SetScript("OnEvent", function(self, event, ...) -- This frame is for initial event handling only
	
		local loadedAddonName = ...;
	
		if event == "ADDON_LOADED" and loadedAddonName == addonName then -- addon has been loaded, savedVars are available -> Create frames before PLAYER_LOGIN to have the game save their position automatically
		
			LoadSettings();
			CreateActionButton();
			
		elseif event == "PLAYER_LOGIN" and loadedAddonName == addonName then -- Frames have been created, everything is ready for use -> Display login message (if enabled)
		
			local clientVersion, clientBuild = GetBuildInfo(); 
			if settings.showLoginMessage then ChatMsg(format(L["%s %s for WOW %s loaded!"], addonName, addonVersion, clientVersion)); end
			
		elseif event == "PLAYER_ENTERING_WORLD" then -- Register for events required to update
		
			Debug(format("Registering button update events...", event));
			RegisterUpdateEvents();

		end
	end);
	
	-- Add slash command to global command list
	SLASH_TOTALAP1, SLASH_TOTALAP2 = "/totalap", slashCommand;
	SlashCmdList["TOTALAP"] = SlashCommandHandler;
	
	-- Add keybinds to Blizzard's KeybindUI
	BINDING_HEADER_TOTALAP = L["TotalAP - Artifact Power Tracker"];
	_G["BINDING_NAME_CLICK TotalAPButton:LeftButtonUp"] = L["Use Next AP Token"];
	_G["BINDING_NAME_TOTALAPBUTTONTOGGLE"] = L["Show/Hide Button"];
end