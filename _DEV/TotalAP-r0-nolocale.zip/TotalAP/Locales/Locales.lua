local L;
L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "enGB", true);

L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "deDE", true); -- Testing purposes only, for now
if L then
	L["TotalAP: <DE> Item counter enabled."] = true;
	L["TotalAP: <DE> Item counter disabled."] = true;
	L["TotalAP:  <DE> Progress report enabled."] = true;
	L["TotalAP: <DE> Progress report disabled."] = true;
	L["TotalAP:  <DE> Default settings loaded."] = true;
	L[" <DE> Toggle display of the item counter"] = true;
	L[" <DE> Toggle display of the progress report"] = true;
	L[" <DE>: List of available commands"] = true;
	L[" <DE> Load default settings (will overwrite any changes made)"] = true;
	L[" <DE> \n%s Artifact Power in bags (%d items)"] = true;
	L[" <DE> \n%d Artifact Power in bags"] = true;
	L[" <DE> %d new traits available - Use AP now to level up!"] = true;
	L[" <DE> New trait available - Use AP now to level up!"] = true;
	L[" <DE> Progress towards next trait: %d%%"] = true;
	L[" <DE> TotalAP loaded!"] = true;
	end
	
L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "esES", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "esMX", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "frFR", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "koKR", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "ruRU", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "zhCN", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "zhTW", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "ptBR", true); 
if L then
	L["TotalAP: Item counter enabled."] = true;
L["TotalAP: Item counter disabled."] = true;
L["TotalAP: Progress report enabled."] = true;
L["TotalAP: Progress report disabled."] = true;
L["TotalAP: Default settings loaded."] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["TotalAP: List of available commands"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%d Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;
L["TotalAP loaded!"] = true;
end