local itemEffects; -- loaded from separate (script-generated) file: ItemEffects\ItemEffects.lua via global TotalAP

local L = LibStub("AceLocale-3.0"):GetLocale("TotalAP") -- Default locale = enGB (also US), most others are still TODO

-- Shorthands
local aUI = C_ArtifactUI

-- Internal vars
local mouseoverItemLink, mouseoverItemID; -- the item currently displayed in the tooltip (which has to be an AP item for the addon to display its info)
local numItems, inBagsTotalAP = 0, 0; -- info to be displayed in the tooltip addition


 -- Helper functions
 local function SeparateDigits(number, thousands, decimal)
	local t = {}
	if not thousands then
		thousands = ","
	end
	if not decimal then
		decimal = "."
	end
	local int = math.floor(number)
	local rest = number % 1
	if int == 0 then
		t[#t+1] = 0
	else
		local digits = math.log10(int)
		local segments = math.floor(digits / 3)
		t[#t+1] = math.floor(int / 1000^segments)
		for i = segments-1, 0, -1 do
			t[#t+1] = thousands
			t[#t+1] = ("%03d"):format(math.floor(int / 1000^i) % 1000)
		end
	end
	if rest ~= 0 then
		t[#t+1] = decimal
		rest = math.floor(rest * 10^6)
		while rest % 10 == 0 do
			rest = rest / 10
		end
		t[#t+1] = rest
	end
	local s = table.concat(t)
	wipe(t)
	return s
end
 
 local function Short(value,format) 
	if type(value) == "number" then
		local fmt
		if value >= 1000000000 or value <= -1000000000 then
			fmt = "%.1fb"
			value = value / 1000000000
		elseif value >= 10000000 or value <= -10000000 then
			fmt = "%.1fm"
			value = value / 1000000
		elseif value >= 1000000 or value <= -1000000 then
			fmt = "%.2fm"
			value = value / 1000000
		elseif value >= 100000 or value <= -100000 then
			fmt = "%.0fk"
			value = value / 1000
		elseif value >= 10000 or value <= -10000 then
			fmt = "%.1fk"
			value = value / 1000
		else
			fmt = "%d"
			value = math.floor(value + 0.5)
		end
		if format then
			return fmt:format(value)
		end
		return fmt, value
	else
		local fmt_a, fmt_b
		local a, b = value:match("^(%d+)/(%d+)$")
		if a then
			a, b = tonumber(a), tonumber(b)
			if a >= 1000000000 or a <= -1000000000 then
				fmt_a = "%.1fb"
				a = a / 1000000000
			elseif a >= 10000000 or a <= -10000000 then
				fmt_a = "%.1fm"
				a = a / 1000000
			elseif a >= 1000000 or a <= -1000000 then
				fmt_a = "%.2fm"
				a = a / 1000000
			elseif a >= 100000 or a <= -100000 then
				fmt_a = "%.0fk"
				a = a / 1000
			elseif a >= 10000 or a <= -10000 then
				fmt_a = "%.1fk"
				a = a / 1000
			end
			if b >= 1000000000 or b <= -1000000000 then
				fmt_b = "%.1fb"
				b = b / 1000000000
			elseif b >= 10000000 or b <= -10000000 then
				fmt_b = "%.1fm"
				b = b / 1000000
			elseif b >= 1000000 or b <= -1000000 then
				fmt_b = "%.2fm"
				b = b / 1000000
			elseif b >= 100000 or b <= -100000 then
				fmt_b = "%.0fk"
				b = b / 1000
			elseif b >= 10000 or b <= -10000 then
				fmt_b = "%.1fk"
				b = b / 1000
			end
			local fmt = ("%s/%s"):format(fmt_a, fmt_b)
			if format then
				return fmt:format(a, b)
			end
			return fmt, a, b
		else
			return value
		end
	end
end
	
	-- Colour coding for chat messages. TODO: Use predefined constants instead? But they don't look as pretty :(
local function GetColour(colour, msg)
	local hexTable = {
		["MSG_NORMAL"] = "FFFFFF",
		["MSG_PROGRESS"] = "CC5500",
		["MSG_NOTE"] = "ECEC0F",
		["MSG_CONFIRM"] = "20FF20",
		["MSG_DEBUG"] = "20FF20",
		["MSG_ERROR"] = "FF1A1A",
		["REPGAIN"] = "8179EB", -- test
		["ARTIFACT"] = "E6CC80", 
	}
	
	if hexTable[colour] and msg then return "|c00" .. hexTable[colour] .. msg;
	else return msg; -- Default chat colour
	end
end

-- Load saved vars and itemEffects DB
local function LoadSettings()
	
	-- Load item effects from global (shared) var
	itemEffects = TotalAP.itemEffects;
	
	if not TotalArtifactPowerDB then TotalArtifactPowerDB = {}; end -- first initialisation = create empty DB table. TODO: Check savedVars for validity (type == ...) etc?
	db = TotalArtifactPowerDB;
	
	-- load default values if not saved before
	if db.showNumItems == nil then db.showNumItems = true; end
	if db.showProgressReport == nil then db.showProgressReport =  true; end
	
end

-- Slash command handler
local function SlashFunction(msg)

	msg = string.lower(msg)
	local command, param = msg:match("^(%S*)%s*(.-)$")
	
	if command == "counter" then
	
		-- Enable counter
		if not db.showNumItems then print(GetColour("MSG_NOTE", L["TotalAP: Item counter enabled."]));
		else print(GetColour("MSG_NOTE", L["TotalAP: Item counter disabled."]));
		end
		
		db.showNumItems = not db.showNumItems;
		
	elseif command == "progress" then
	
		-- Enable progress reports
		if not db.showProgressReport then print(GetColour("MSG_NOTE", L["TotalAP: Progress report enabled."]));
		else print(GetColour("MSG_NOTE", L["TotalAP: Progress report disabled."]));
		end
		
		db.showProgressReport = not db.showProgressReport;
		
	elseif command == "reset" then
		-- Load default values
		db.showNumItems = true;
		db.showProgressReport = true;
		print(GetColour("MSG_NOTE", L["TotalAP: Default settings loaded."]));
		
	else
		-- Display help
		print(GetColour("ARTIFACT", L["TotalAP: List of available commands"]));
		print(GetColour("MSG_PROGRESS", "/totalap counter - " .. L["Toggle display of the item counter"]));
		print(GetColour("MSG_PROGRESS", "/totalap progress - " .. L["Toggle display of the progress report"]));
		print(GetColour("MSG_PROGRESS", "/totalap reset - " .. L["Load default settings (will overwrite any changes made)"]));
		
	end
	
end

-- Check for artifact power tokens in the player's bags (not bank. TODO?)
 local function CheckBags()
 
	local bag, slot;
	numItems, inBagsTotalAP = 0, 0; -- each new bag scan has to reset the counter, obviously...
	
	-- Check all the items in bag against AP token LUT to find matches
	for bag = 0, NUM_BAG_SLOTS do
		for slot = 1, GetContainerNumSlots(bag) do
			mouseoverItemLink = GetContainerItemLink(bag, slot);

			if mouseoverItemLink and mouseoverItemLink:match("item:%d")  then
					mouseoverItemID = GetItemInfoInstant(mouseoverItemLink);
					local spellID = itemEffects[mouseoverItemID];
					
				if spellID then	-- Found AP token :D	
					numItems = numItems + 1
					-- Extract AP amount (after AK is applied) from the description
					local spellDescription = GetSpellDescription(spellID); -- Always contains the AP number (after AK was applied), as only AP tokens are in the LUT
					
					local m = spellDescription:match("%s(%d+%,?%.?%s?%d*)%s");  -- Match pattern: <space><number | number separated by comma, point, or space> <space> => This is the AP amount displayed! TODO: Does this work in all locales? Asia, I'm looking at you...
					m = string.gsub(string.gsub(m, "%,", ""), "%.", ""); -- Poof! All commas and points (separators) are gone. Simply vanished! Like magic.
					inBagsTotalAP = inBagsTotalAP + tonumber(m);
				end
			end
		end
	end
	
end

-- whenever an item tooltip is shown
GameTooltip:HookScript('OnTooltipSetItem', function(self)

	CheckBags() -- Check bags for any AP items and save number and total amount of AP found in addon vars

	-- Embed results in item tooltip
	local _, mouseoverItemLink = self:GetItem();
	if type(mouseoverItemLink) == "string" then

		mouseoverItemID = GetItemInfoInstant(mouseoverItemLink);
		
		if itemEffects[mouseoverItemID] then -- Only display tooltip addition for AP tokens
			
			local artifactID, _, artifactName = C_ArtifactUI.GetEquippedArtifactInfo();
			
			if artifactID and artifactName then	

				-- Display spec and artifact info
				local spec = GetSpecialization();
				if spec then
					local _, specName, _, specIcon, _, specRole = GetSpecializationInfo(spec);
					local classDisplayName, classTag, classID = UnitClass("player");
					
					if specIcon then
						self:AddLine(format('\n|T%s:16|t [%s]', specIcon,  artifactName), 230/255, 204/255, 128/255); -- TODO: Colour green/red or something if it's the offspec? Can use classTag or ID for this
					end
				end
			
				-- Display AP summary
				if numItems > 1 and db.showNumItems then 
					self:AddLine(format(L["\n%s Artifact Power in bags (%d items)"], Short(inBagsTotalAP, true), numItems), 230/255, 204/255, 128/255);
				else
					self:AddLine(format(L["\n%d Artifact Power in bags"], Short(inBagsTotalAP, true)) , 230/255, 204/255, 128/255);
				end
			
				-- Calculate progress
				if HasArtifactEquipped() and db.showProgressReport	then
							
						local itemID, altID, name, resID, thisLevelUnspentAP, numTraits, _, _, _, _, _, _ = aUI.GetEquippedArtifactInfo();							
						local nextLevelRequiredAP = aUI.GetCostForPointAtRank(numTraits); 
						local percentageWithoutUnspentAP = inBagsTotalAP / nextLevelRequiredAP*100;
						local percentageOfCurrentLevelUp = (thisLevelUnspentAP + inBagsTotalAP) / nextLevelRequiredAP*100;

						-- Display progress
						local numTraitsAvailable = MainMenuBar_GetNumArtifactTraitsPurchasableFromXP(numTraits, thisLevelUnspentAP + inBagsTotalAP) -- This is how many times the weapon can be leveled up with AP from bags AND already used (but not spent) AP from this level

						--Identical to: if percentageOfCurrentLevelUp >= 100 then
						if numTraitsAvailable > 1 then -- several new traits are available
							self:AddLine(format(L["%d new traits available - Use AP now to level up!"], numTraitsAvailable), 0/255, 255/255, 0/255);
						elseif numTraitsAvailable > 0 then -- exactly one new is trait available
							self:AddLine(format(L["New trait available - Use AP now to level up!"]), 0/255, 255/255, 0/255);
						else -- No traits available - too bad :(
							self:AddLine(format(L["Progress towards next trait: %d%%"], percentageOfCurrentLevelUp));
						end
				end
			end
		self:Show();
		end
	end
end)

 -- one-time execution on load
 do
	LoadSettings();  -- from saved vars
	
	local f = CreateFrame("Frame", "InvisibleTotalAPFrame");

	f:RegisterEvent("PLAYER_LOGIN");
	f:SetScript("OnEvent", function(self, event, ...)
		if event == "PLAYER_LOGIN" then
		LoadSettings();
		print(GetColour("ARTIFACT", L["TotalAP loaded!"]));  -- TODO: Display version? Or hide entirely?
		end
	end)

	SLASH_TOTALAP1 = "/totalap";
	SlashCmdList["TOTALAP"] = SlashFunction;
end