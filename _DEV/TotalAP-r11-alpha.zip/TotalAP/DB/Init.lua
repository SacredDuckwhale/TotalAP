-- [[ Initialise TotalArtifactPowerDB ]] --

if not TotalArtifactPowerDB then
	TotalArtifactPowerDB = {};
end

-- Might add more stuff here later. For the time being, the individual DB files will add their data to populate the DB, which can then be used by the addon itself