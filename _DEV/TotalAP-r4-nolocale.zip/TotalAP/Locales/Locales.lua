local L;
L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "enGB", true);

-- Login message
L["%s %s for WOW %s loaded!"] = true;

-- Slash command handler
L["[List of available commands]"] = true;
L["Toggle display of the item counter"] = true;
L["Toggle display of the progress report"] = true;
L["Toggle spell overlay notification (glow effect) when new traits are available"] = true;
L["Toggle button visibility (tooltip visibility is unaffected)"] = true;
L["Toggle login message on load"] = true;
L["Load default settings (will overwrite any changes made)"] = true;
L["Toggle debug mode (not particularly useful as long as everything is working as expected)"] = true;

L["Item counter enabled."] = true;
L["Item counter disabled."] = true;
L["Progress report enabled."] = true;
L["Progress report disabled."] = true;
L["Button glow effect enabled."] = true;
L["Button glow effect disabled."] = true;
L["Action button is now hidden."] = true;
L["Action button is now.shown."] = true;
L["Login message is now hidden."] = true;
L["Login message is now shown."] = true;
L["Default settings loaded."] = true;
L["Debug mode enabled."] = true;
L["Debug mode disabled."] = true;

-- Tooltip text
L["\n%s Artifact Power in bags (%d items)"] = true;
L["\n%s Artifact Power in bags"] = true;
L["%d new traits available - Use AP now to level up!"] = true;
L["New trait available - Use AP now to level up!"] = true;
L["Progress towards next trait: %d%%"] = true;

-- Keybind UI
L["TotalAP - Artifact Power Tracker"] = true;
L["Use Next AP Token"] = true;
L["Show/Hide Button"] = true;


-- TODO Other locales aren't included yet. Use WowInterface/CurseForge to localise and update strings
L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "deDE", true); -- Testing purposes only, for now
if L then
	-- Login message
	L["%s %s for WOW %s loaded!"] = true;

	-- Slash command handler
	L["[List of available commands]"] = true;
	L["Toggle display of the item counter"] = true;
	L["Toggle display of the progress report"] = true;
	L["Toggle spell overlay notification (glow effect) when new traits are available"] = true;
	L["Toggle button visibility (tooltip visibility is unaffected)"] = true;
	L["Toggle login message on load"] = true;
	L["Load default settings (will overwrite any changes made)"] = true;
	L["Toggle debug mode (not particularly useful as long as everything is working as expected)"] = true;

	L["Item counter enabled."] = true;
	L["Item counter disabled."] = true;
	L["Progress report enabled."] = true;
	L["Progress report disabled."] = true;
	L["Button glow effect enabled."] = true;
	L["Button glow effect disabled."] = true;
	L["Action button is now hidden."] = true;
	L["Action button is now.shown."] = true;
	L["Login message is now hidden."] = true;
	L["Login message is now shown."] = true;
	L["Default settings loaded."] = true;
	L["Debug mode enabled."] = true;
	L["Debug mode disabled."] = true;

	-- Tooltip text
	L["\n%s Artifact Power in bags (%d items)"] = true;
	L["\n%s Artifact Power in bags"] = true;
	L["%d new traits available - Use AP now to level up!"] = true;
	L["New trait available - Use AP now to level up!"] = true;
	L["Progress towards next trait: %d%%"] = true;

	-- Keybind UI
	L["TotalAP - Artifact Power Tracker"] = true;
	L["Use Next AP Token"] = true;
	L["Show/Hide Button"] = true;
end
	
L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "esES", true); 
if L then
	
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "esMX", true); 
if L then

end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "frFR", true); 
if L then

end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "koKR", true); 
if L then

end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "ruRU", true); 
if L then
	
end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "zhCN", true); 
if L then

end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "zhTW", true); 
if L then

end

L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "ptBR", true); 
if L then

end